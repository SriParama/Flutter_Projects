import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:insta_firebase/resources/auth_mehods.dart';
import 'package:insta_firebase/responsive/mobile_screen_layout.dart';
import 'package:insta_firebase/responsive/responsive_layout_screen.dart';
import 'package:insta_firebase/responsive/web_screen_layout.dart';
import 'package:insta_firebase/screens/login_screen.dart';
import 'package:insta_firebase/screens/notifivationScreen.dart';
import 'package:insta_firebase/screens/siginup_screen.dart';
import 'package:insta_firebase/utils/colors.dart';

final navigatorKey = GlobalKey<NavigatorState>();

void main() async {
  try {
    WidgetsFlutterBinding.ensureInitialized();

    if (kIsWeb) {
      await Firebase.initializeApp(
        options: const FirebaseOptions(
          apiKey: "AIzaSyAa-Y1pRRWIlG5_5Fg_U72UFa9vD4IvOUE",
          appId: "1:563342547552:web:276dc75d345d988751c105",
          messagingSenderId: "563342547552",
          projectId: "instagram-clone-79db2",
          storageBucket: "instagram-clone-79db2.appspot.com",
        ),
      );
      await AuthMethods().initNotifications();
    } else {
      await Firebase.initializeApp(
          options: const FirebaseOptions(
        apiKey: "AIzaSyD3oPp2Z1Laf222-7q5boFKTKyG7Rz3DgA",
        appId: "1:563342547552:android:bc9ecc46ee08867451c105",
        messagingSenderId: "563342547552",
        projectId: "instagram-clone-79db2",
        storageBucket: "instagram-clone-79db2.appspot.com",
      ));
      await AuthMethods().initNotifications();
    }
  } catch (e) {
    print(e.toString());
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData.dark()
          .copyWith(scaffoldBackgroundColor: mobileBackgroundColor),
      // home: ResponsiveLayout(
      //     webScreenLayout: WebScreenLayout(),
      //     mobileScreenLayout: MobileLayout())
      home: LoginScreen(),

      navigatorKey: navigatorKey,
      routes: {
        NotificationScreen.route: (context) => const NotificationScreen()
      },
      // home: SignupScreen(),
    );
  }
}
